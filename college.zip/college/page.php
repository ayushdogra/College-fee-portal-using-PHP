<?php
// Merchant key here as provided by Payu
$MERCHANT_KEY = "2UtKikQS";

// Merchant Salt as provided by Payu
$SALT = "dHmiAzGWDT";

// End point - change to https://secure.payu.in for LIVE mode
$PAYU_BASE_URL = "https://test.payu.in";

$action = '';

$posted = array();
if(!empty($_POST)) {
    //print_r($_POST);
  foreach($_POST as $key => $value) {
    $posted[$key] = $value;

  }
}

$formError = 0;

if(empty($posted['txnid'])) {
  // Generate random transaction id
  $txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
} else {
  $txnid = $posted['txnid'];
}
$hash = '';
// Hash Sequence
$hashSequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";
if(empty($posted['hash']) && sizeof($posted) > 0) {
  if(
          empty($posted['key'])
          || empty($posted['txnid'])
          || empty($posted['amount'])
          || empty($posted['firstname'])
   || empty($posted['service_provider'])
  ) {
    $formError = 1;
  } else {
    //$posted['productinfo'] = json_encode(json_decode('[{"name":"tutionfee","description":"","value":"500","isRequired":"false"},{"name":"developmentfee","description":"monthly tution fee","value":"1500","isRequired":"false"}]'));
 $hashVarsSeq = explode('|', $hashSequence);
    $hash_string = '';
 foreach($hashVarsSeq as $hash_var) {
      $hash_string .= isset($posted[$hash_var]) ? $posted[$hash_var] : '';
      $hash_string .= '|';
    }

    $hash_string .= $SALT;


    $hash = strtolower(hash('sha512', $hash_string));
    $action = $PAYU_BASE_URL . '/_payment';
  }
} elseif(!empty($posted['hash'])) {
  $hash = $posted['hash'];
  $action = $PAYU_BASE_URL . '/_payment';
}
?>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "student";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM student_detail WHERE roll_no=".$_GET['ROLLNO']."";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title></title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <script>
    var hash = '<?php echo $hash ?>';
    function submitPayuForm() {
      if(hash == '') {
        return;
      }
      var payuForm = document.forms.payuForm;
      payuForm.submit();
    }
  </script>
</head>
<body>
  <nav class="navbar navbar-dark bg-dark ">
    <a href="http://www.uiit.ac.in/" class="navbar-brand" target="_blank">Uiit</a>
    <ul class="navbar-nav">
      <li class="navbar-item" style="color:white"> <b>Student fee details</b></li>
    </ul>
  </nav>
  <div class="h2 text-center" style="margin-top:40px;margin-left:40px;">
  Fee Details
  </div>
  <div class="col-md-6 offset-md-3">
  <div class="text-center">
  <table class="table table-bordered">
 <?php while($row = $result->fetch_assoc()) {
      ?>
  <tr>
  <td><strong>Name</strong></td>
  <td><?php echo $row['name']; ?></td>
  </tr>
  <tr>
  <td>Roll Number</td>
  <td><?php echo $row['roll_no'];  ?></td>
  </tr>
  <tr>
  <td>Address</td>
  <td><?php echo $row['address'];  ?></td>
  </tr>
  <tr>
  <td>Current Sem</td>
  <td><?php echo $row['sem'];  ?></td>
  </tr>
  <tr>
  <td><strong>Current Fee Details</strong></td>
  <td><strong><?php echo $row['fee'];  ?></strong></td>
  </tr>
  <tr>
  <td>Previous Fee Details</td>
  <td><?php echo $row['last_fee'].'('.$row['prev_sem'].')'  ?></td>
  </tr>
  <?php }
    ?>
  </table>
  </div>
  </div>
  <form action="<?php echo $action; ?>" method="post" name="payuForm" class="text-center">
      <input type="hidden" name="key" value="<?php echo $MERCHANT_KEY ?>" />
      <input type="hidden" name="hash" value="<?php echo $hash ?>"/>
      <input type="hidden" name="txnid" value="<?php echo $txnid ?>" />
      <input type="hidden" name="service_provider" value="payu_paisa" size="64" />
      <input type="hidden" name="productinfo" value="College Fee"/>
      <input type="hidden" name="surl" value="uiit" size="64" />
      <input type="hidden" name="email" value="dograayush12@gmail.com" size="64" />
      <input type="hidden" name="phone" value="9459790555" size="64" />
      <?php
      $sql = "SELECT * FROM student_detail WHERE roll_no=".$_GET['ROLLNO']."";
      $result = $conn->query($sql);
      while($row = $result->fetch_assoc()) {
      ?>
      <input type="hidden" name="firstname" id="firstname" value="<?php echo ($row['name'])?>" />
      <input type="hidden" name="amount" value="<?php echo ($row['fee'])?>" />
      <?php } ?>
      <div style="margin:auto;">
      <button type="submit" name="button" class="btn btn-success">SUBMIT FEES HERE</button>
    </div>
  </form>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>
<?php
}
else{
 echo 'No records found. Please try again';
}
?>
